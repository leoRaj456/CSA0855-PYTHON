base = float(input("enter the base of the triangle: "))
height = float(input("enter the height of the triangle: "))
area_triangle = 0.5 * base * height
print(f"Area of the triangle: {area_triangle}")
