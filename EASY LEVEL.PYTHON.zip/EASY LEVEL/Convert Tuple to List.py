tup = tuple(map(int, input("enter elements of tuple separated by space: ").split()))
lst = list(tup)
print("converted list:", lst)
