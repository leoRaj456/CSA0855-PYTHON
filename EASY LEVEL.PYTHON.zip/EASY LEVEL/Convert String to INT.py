str_num = input("enter a string representing an integer: ")
num = int(str_num)
print("converted integer:", num)
