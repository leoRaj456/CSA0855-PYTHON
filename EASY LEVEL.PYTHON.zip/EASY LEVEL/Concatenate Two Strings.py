str1 = input("enter the first string: ")
str2 = input("enter the second string: ")
concat_str = str1 + str2
print("concatenated string:", concat_str)
