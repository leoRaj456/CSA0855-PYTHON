str_num = input("enter a string representing a float: ")
num = float(str_num)
print("converted float:", num)
