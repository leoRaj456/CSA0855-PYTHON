lst = list(map(int, input("enter elements of list separated by space: ").split()))
lst.sort()
print("list in ascending order:", lst)
