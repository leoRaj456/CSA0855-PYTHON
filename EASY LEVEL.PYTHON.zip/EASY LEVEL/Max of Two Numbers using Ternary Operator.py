a = int(input("enter the first number: "))
b = int(input("enter the second number: "))
max_val = a if a > b else b
print(f"Maximum of {a} and {b}: {max_val}")
