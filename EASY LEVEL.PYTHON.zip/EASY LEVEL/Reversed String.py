str_val = input("enter a string to reverse: ")
reversed_str = str_val[::-1]
print("reversed string:", reversed_str)
