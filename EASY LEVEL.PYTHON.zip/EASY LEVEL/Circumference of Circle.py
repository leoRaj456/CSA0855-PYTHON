import math
radius = float(input("enter the radius of the circle: "))
circumference = 2 * math.pi * radius
print(f"Circumference of the circle: {circumference}")
