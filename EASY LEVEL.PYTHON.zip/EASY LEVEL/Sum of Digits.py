num = input("enter a number: ")
sum_digits = sum(int(digit) for digit in num)
print("sum of digits are ", sum_digits)
