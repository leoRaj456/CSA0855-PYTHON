password = input("enter a password: ")
valid_pass = len(password) >= 8
print("Is the password valid?", valid_pass)
