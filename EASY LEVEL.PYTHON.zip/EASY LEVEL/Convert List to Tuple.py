lst = list(map(int, input("enter elements of list separated by space: ").split()))
tup = tuple(lst)
print("converted tuple:", tup)
