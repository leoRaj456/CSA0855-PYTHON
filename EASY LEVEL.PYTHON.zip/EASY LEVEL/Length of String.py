str_val = input("enter a string: ")
print("length of the string:", len(str_val))
