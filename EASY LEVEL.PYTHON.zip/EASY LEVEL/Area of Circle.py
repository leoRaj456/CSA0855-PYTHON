import math
radius = float(input("enter the radius of the circle: "))
area_circle = math.pi * radius ** 2
print(f"Area of the circle: {area_circle}")
