n = int(input("enter a number N to calculate the sum of first N natural numbers: "))
sum_n = n * (n + 1) // 2
print(f"Sum of first {n} natural numbers is", sum_n)
