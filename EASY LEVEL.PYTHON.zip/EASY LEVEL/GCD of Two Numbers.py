import math
a = int(input("enter the first number: "))
b = int(input("enter the second number: "))
gcd = math.gcd(a, b)
print(f"GCD of {a} and {b} is {gcd}")
