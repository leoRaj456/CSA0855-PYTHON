lst = list(map(int, input("enter elements of list separated by space: ").split()))
average = sum(lst) / len(lst)
print(f"Average of the list: {average}")
